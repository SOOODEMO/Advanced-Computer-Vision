# Advanced-Computer-Vision-using-OpenCV-Python
Advanced Computer Vision using OpenCV Python is a course designed by me, to share my experience with OpenCV Python, Deep Learning and Machine Learning.

You can find video tutorials here : https://www.youtube.com/playlist?list=PLwRoxHWReaEhVFjTeKlifKUimbw6ZyV7K

