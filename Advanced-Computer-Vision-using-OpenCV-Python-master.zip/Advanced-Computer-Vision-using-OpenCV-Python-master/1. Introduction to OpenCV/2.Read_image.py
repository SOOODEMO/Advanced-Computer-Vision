# -*- coding: utf-8 -*-
"""
Created on Sun Nov 17 10:59:33 2019

@author: Jaimin
"""

# Import opencv
import cv2

# Read image
img = cv2.imread("glasses.jpg")


print(img.shape)
