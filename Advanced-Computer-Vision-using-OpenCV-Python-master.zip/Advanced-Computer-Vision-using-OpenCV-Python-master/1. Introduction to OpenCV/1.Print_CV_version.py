# -*- coding: utf-8 -*-
"""
Created on Sun Nov 17 10:56:17 2019

@author: Jaimin
"""

# import opencv
import cv2

# print opencv version
print(cv2.__version__)